﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Forms_CRUD_.Migrations
{
    public partial class PhotoPath : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "SomeProperty",
                table: "Students");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "SomeProperty",
                table: "Students",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }
    }
}
