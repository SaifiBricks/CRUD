﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Forms_CRUD_.Migrations
{
    public partial class SeedStudent : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Students",
                columns: new[] { "Id", "Description", "Email", "Name" },
                values: new object[] { 1, "I am salamander", "salder22@gmail.com", "salamander" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Students",
                keyColumn: "Id",
                keyValue: 1);
        }
    }
}
