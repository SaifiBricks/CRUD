﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Forms_CRUD_.Migrations
{
    public partial class PhotoPathColumn : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "PhotoPath",
                table: "Students",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.UpdateData(
                table: "Students",
                keyColumn: "Id",
                keyValue: 1,
                columns: new[] { "Description", "Name" },
                values: new object[] { "I am salam", "salam" });

            migrationBuilder.InsertData(
                table: "Students",
                columns: new[] { "Id", "Description", "Email", "Name", "PhotoPath" },
                values: new object[] { 2, "I am salamander", "salder22@gmail.com", "salamander", null });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Students",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DropColumn(
                name: "PhotoPath",
                table: "Students");

            migrationBuilder.UpdateData(
                table: "Students",
                keyColumn: "Id",
                keyValue: 1,
                columns: new[] { "Description", "Name" },
                values: new object[] { "I am salamander", "salamander" });
        }
    }
}
