﻿using Microsoft.AspNetCore.Mvc;

namespace Forms_CRUD_.Controllers
{
    public class HomeController1 : Controller
    {
        [Route("/Error/{statusCode}")]
        public IActionResult HttpStatusCodeHandler(int statusCode)
        {
            switch (statusCode)
            {
                case 404:
                    ViewBag.ErrorMessage = "Sorry page not found";
                    break;
            }
            return View("NotFound");
        }
    }
}
